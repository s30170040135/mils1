package wiproms1;

public class co4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num=310;
		if(num>0)
		{
			System.out.println(num+ " is a positive number");
		}
		else if(num<0)
		{
			System.out.println(num+ " is a negative number");
			
		}
		else
		{
			System.out.println(num+ " is neither positive nor negative");
		}
	}

}
