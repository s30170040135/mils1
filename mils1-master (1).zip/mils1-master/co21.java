package wiproms1;

public class co21 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i;
		for(i=1;i<=10;i++)
		{
			System.out.print(i+"\t");
		}

	}

}
