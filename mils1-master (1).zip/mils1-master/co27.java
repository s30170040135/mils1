package wiproms1;

public class co27 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num[] = {65, 66, 67, 68, 69};
        String str =null;
        for(int i: num){
            str = Character.toString((char)i);
            System.out.println(str);
        }
	}

}
