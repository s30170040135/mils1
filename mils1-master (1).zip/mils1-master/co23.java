package wiproms1;

public class co23 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 char item1='e';
	        char item2='b';
	        if (item1>item2)
	            System.out.println(item2+" , "+item1);
	       
	        else
	            System.out.println(item1+" , "+item2);
}
	}


