package wiproms1;

public class co3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a,b;
		a=10;
		b=15;
		System.out.print("The sum of "+a+" and "+b+" is "+(a+b));
	}

}
