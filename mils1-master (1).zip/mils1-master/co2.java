package wiproms1;

public class co2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str1,str2;
		str1= "Wipro";
		str2= "Bangalore";
		System.out.print(str1+" Technologies "+str2);
	}

}
