package wiproms1;

public class co19 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num=13;
		if(num%2==0)
		{
			System.out.println(num+" is even number");
			
		}
		else
		{
			System.out.println(num+" is odd number");
		}

	}

}
